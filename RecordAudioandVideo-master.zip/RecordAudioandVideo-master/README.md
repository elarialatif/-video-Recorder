# RecordAudioandVideo

Know more details

https://medium.com/@manivannan_data/record-audio-video-image-and-gif-from-browser-using-videojs-record-2249fcc6ea9e
